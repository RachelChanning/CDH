package com.sjj.service;

public interface IOperateHiveWithSpark {
	void launch() throws Exception;
}
