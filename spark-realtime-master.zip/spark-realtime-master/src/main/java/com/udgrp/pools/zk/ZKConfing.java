

package com.udgrp.pools.zk;

/**
 * Created by kejw on 2017/10/14.
 */
public interface ZKConfing {
    public static final String ZK_SERVERS = "localhost:2181";
    public static final int SESSION_TIMEOUT = 10000;
    public static final int CONNECTION_TIMEOUT = 10000;
}
