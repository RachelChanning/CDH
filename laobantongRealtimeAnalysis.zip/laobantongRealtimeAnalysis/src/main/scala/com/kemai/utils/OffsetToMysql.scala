package com.kemai.utils

object OffsetToMysql {

}
