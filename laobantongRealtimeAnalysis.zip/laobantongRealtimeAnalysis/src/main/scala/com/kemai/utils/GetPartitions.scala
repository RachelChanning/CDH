package com.kemai.utils

import java.util
import java.util.Properties

import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.common.PartitionInfo

object GetPartitions {
  def main(args: Array[String]): Unit = {
    /*//设置spark的配置文件信息
    val sparkConf: SparkConf = new SparkConf().setAppName("WordCount").setMaster("local[2]")
    //构建sparkcontext上下文对象，它是程序的入口,所有计算的源头
    val sc: SparkContext = new SparkContext(sparkConf)
    //读取文件
    val file: RDD[String] = sc.textFile("file://///D:/qinweixin2019/科脉项目/老板通实时指标分析_190909/software/kafka实时测试数据/0_YT1013_2c441920018252ec2b7d499c7af62791_2016101908_42.txt")
    println("file: " + file.toString())

    sc.stop()*/


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    getPartitions("order0911")
  }

  def getPartitions(topicName: String): Int =  {
    val props = new Properties()
    props.put("bootstrap.servers","192.168.251.75:9092,192.168.251.76:9092")
    props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    props.put("request.required.acks", "1")
    props.put("producer.type", "async")

    val producer = new KafkaProducer[String,String](props)
    val list: util.List[PartitionInfo] = producer.partitionsFor(topicName);
    System.out.println("partitions = " + list.size());
    return list.size();
  }
}
