package com.kemai

import com.kemai.utils.{GetPartitions, InternalRedisClient, OffsetToRedis}
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

/**
  *
  * Title: KafkaToSparkstreaming
  * Description:
  * Version: 老板通数据实时指标分析
  * @author John Qin
  * @date   2019-9-12 16:23:57
  */
object KafkaToSparkstreaming {
  def main(args: Array[String]): Unit = {
    //初始化Redis Pool
    OffsetToRedis.initRedisPool()

    val sparkConf = new SparkConf().setMaster("local[4]").setAppName("KafkaToSparkstreaming")
    val sparkContext = new SparkContext(sparkConf)
    sparkContext.setLogLevel("WARN")
    val ssc = new StreamingContext(sparkContext, Seconds(3))

    val bootstrapServers = "192.168.251.75:9092,192.168.251.76:9092"
    val groupId = "kafka-test-group"
    val topicName = "order0910"
    val maxPoll = 20000/////////////////////

    val kafkaParams = Map(
      "bootstrap.servers" -> bootstrapServers,
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      //
      "group.id" -> groupId,
      //
      "auto.offset.reset" -> "latest",
      //
      "enable.auto.commit" -> (false: java.lang.Boolean)
    )
    /*val kafkaParams = Map(
      ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG -> bootstrapServers,
      ConsumerConfig.GROUP_ID_CONFIG -> groupId,
      ConsumerConfig.MAX_POLL_RECORDS_CONFIG -> maxPoll.toString,
      ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG -> classOf[StringDeserializer],
      ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG -> classOf[StringDeserializer]
    )*/

    //获取topic的分区数
    val partitions = GetPartitions.getPartitions(topicName)
    // 这里指定Topic的Partition的总数
    //val fromOffsets = OffsetToRedis.getLastCommittedOffsets(topicName, 1)
    val fromOffsets = OffsetToRedis.getLastCommittedOffsets(topicName, partitions)
    // 初始化kafkaTopicDstream
    val kafkaTopicDstream = KafkaUtils.createDirectStream(ssc, LocationStrategies.PreferConsistent,
      ConsumerStrategies.Assign[String, String](fromOffsets.keys.toList, kafkaParams, fromOffsets))

    /*val jedis = InternalRedisClient.getPool.getResource
    jedis.set("1001", "qin01")
    jedis.get("key01")
    println("key01 = " + jedis.get("key01"))
    jedis.close()*/

    kafkaTopicDstream.foreachRDD(rdd => {
      //offset信息
      val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
      // 如果rdd有数据
      //if (!rdd.isEmpty()) {
      if (rdd.count() > 0) {
        //每个分区当中的数据进行循环遍历，遍历每个分区当中每一行的数据
        rdd.foreach(f => {
          //获取kafka当中的数据内容
          val kafkaValue: String = f.value()
          println(kafkaValue)
        })
        val jedis = InternalRedisClient.getPool.getResource
        //val jedis = InternalRedisClient.getConnection()
        val p = jedis.pipelined()
        p.multi() //开启事务
        //处理数据......

        //更新Offset
        offsetRanges.foreach { offsetRange =>
          println("partition : " + offsetRange.partition + "  fromOffset:  " + offsetRange.fromOffset + " untilOffset: " + offsetRange.untilOffset)
          val topic_partition_key = offsetRange.topic + "_" + offsetRange.partition
          p.set(topic_partition_key, offsetRange.untilOffset + "")
        }
        p.exec() //提交事务
        p.sync //关闭pipeline
        jedis.close()
      }
    })

    ssc.start()
    ssc.awaitTermination()
  }
}
